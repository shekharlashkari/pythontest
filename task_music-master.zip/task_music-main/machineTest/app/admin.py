from django.contrib import admin
from .models import SongDetail
# Register your models here.

admin.site.register(SongDetail)