from django.shortcuts import render
from .models import SongDetail
from .serializer import *
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status

# Create your views here.
class SongUploaderView(viewsets.ModelViewSet):
    serializer_class = SongUploaderSerializer
    queryset = SongDetail.objects.all()